const el = document.getElementById("invoice");
const error = document.getElementById("checkoutError");
const id = location.pathname.split("/").filter(Boolean).pop();
const money = n => new Intl.NumberFormat("id-ID", {style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n);
async function load() {
  try {
    const r = await fetch(`/api/public/payments/${encodeURIComponent(id)}`);
    const d = await r.json(); if (!r.ok) throw new Error(d.error || "Invoice gagal dimuat.");
    const status = {pending:"Menunggu pembayaran",reported:"Menunggu verifikasi admin",paid:"Pembayaran berhasil",failed:"Invoice dibatalkan"}[d.status] || d.status;
    el.innerHTML = `<div class="invoice-meta"><span>Merchant</span><b>${safe(d.merchant)}</b><span>ID Invoice</span><b>${safe(d.external_id)}</b><span>Status</span><b class="status ${d.status}">${status}</b></div><div class="amount">${money(d.amount)}</div><p>${safe(d.description || "Pembayaran pesanan")}</p><div class="qris"><img src="/assets/gopay-qris.jpg" alt="QRIS merchant"></div><div class="notice"><b>Petunjuk pembayaran</b><br>Scan QRIS dengan aplikasi pembayaran, lalu masukkan nominal <b>${money(d.amount)}</b> secara tepat. QR ini statis; pastikan nama merchant dan nominal benar sebelum membayar.</div>${d.status === "pending" ? `<button class="primary full" id="reported">Saya sudah membayar</button><p class="muted small">Tombol ini hanya mengirim laporan, bukan bukti pembayaran otomatis. Admin akan mencocokkan transaksi.</p>` : ""}${d.status === "reported" ? `<p class="notice">Laporan pembayaran diterima. Status akan berubah setelah admin memeriksa mutasi merchant.</p>` : ""}`;
    const btn = document.getElementById("reported"); if (btn) btn.onclick = async () => {
      btn.disabled = true; btn.textContent = "Mengirim laporan...";
      try { const rr = await fetch(`/api/public/payments/${encodeURIComponent(id)}/report`, {method:"POST"}); const dd = await rr.json(); if (!rr.ok) throw new Error(dd.error); await load(); }
      catch(e) { error.textContent = e.message; btn.disabled = false; btn.textContent = "Saya sudah membayar"; }
    };
  } catch(e) { el.textContent = "Invoice tidak ditemukan atau tidak dapat dimuat."; error.textContent = e.message; }
}
function safe(s) { return String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
load();
