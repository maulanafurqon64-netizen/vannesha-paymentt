const $ = id => document.getElementById(id);
async function api(url, opt = {}) {
  const r = await fetch(url, { ...opt, headers: { "Content-Type": "application/json", ...(opt.headers || {}) }, credentials: "same-origin" });
  const d = await r.json().catch(() => ({})); if (!r.ok) throw Error(d.error || "Permintaan gagal."); return d;
}
const money = n => new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(n || 0);
const safe = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
function show() { $("login").classList.add("hide"); $("app").classList.remove("hide"); $("logout").classList.remove("hide"); load(); }
async function load() {
  try {
    const s = await api("/api/admin/stats");
    for (const k of ["total", "pending", "reported", "paid", "failed"]) if ($(k)) $(k).textContent = s[k] ?? 0;
    $("volume").textContent = money(s.volume);
    const [transactions, merchants] = await Promise.all([api("/api/admin/transactions"), api("/api/admin/merchants")]);
    $("tx").innerHTML = transactions.length ? `<div class="table-wrap"><table><thead><tr><th>Invoice / Merchant</th><th>Nominal</th><th>Status</th><th>Aksi</th></tr></thead><tbody>${transactions.map(x => `<tr><td><b>${safe(x.externalId)}</b><small>${safe(x.merchantName || "Merchant")}</small><small>${new Date(x.createdAt).toLocaleString("id-ID")}</small><a href="/pay/${encodeURIComponent(x.id)}" target="_blank" rel="noopener">Buka invoice</a></td><td>${money(x.amount)}</td><td><span class="status ${safe(x.status)}">${safe(x.status)}</span></td><td>${x.status === "pending" || x.status === "reported" ? `<button class="mini success" data-action="paid" data-id="${safe(x.id)}">Tandai lunas</button> <button class="mini danger" data-action="failed" data-id="${safe(x.id)}">Tolak</button>` : "—"}</td></tr>`).join("")}</tbody></table></div>` : "Belum ada transaksi.";
    $("merchantList").innerHTML = merchants.length ? merchants.map(x => `<div class="merchant-row"><span><b>${safe(x.name)}</b><small>${x.active ? "Aktif" : "Nonaktif"}</small></span><button class="mini ${x.active ? "danger" : "success"}" data-merchant="${safe(x.id)}" data-active="${!x.active}">${x.active ? "Nonaktifkan" : "Aktifkan"}</button></div>`).join("") : "Belum ada merchant.";
  } catch (e) { if (e.message.includes("Login")) location.reload(); else console.error(e); }
}
api("/api/admin/me").then(show).catch(() => {});
$("loginForm").addEventListener("submit", async e => {
  e.preventDefault(); const f = new FormData(e.target); const btn = e.submitter; btn.disabled = true;
  try { await api("/api/admin/login", { method: "POST", body: JSON.stringify({ username: f.get("username"), password: f.get("password") }) }); show(); }
  catch (x) { $("error").textContent = x.message; } finally { btn.disabled = false; }
});
$("logout").onclick = async () => { await api("/api/admin/logout", { method: "POST" }); location.reload(); };
$("merchantForm").addEventListener("submit", async e => {
  e.preventDefault(); const name = new FormData(e.target).get("name");
  try { const d = await api("/api/admin/merchants", { method: "POST", body: JSON.stringify({ name }) }); $("keyout").textContent = `SIMPAN API KEY INI SEKARANG (hanya tampil sekali):\n${d.apiKey}`; e.target.reset(); await load(); }
  catch (x) { alert(x.message); }
});
$("refresh").onclick = load;
document.addEventListener("click", async e => {
  const action = e.target.closest("[data-action]"); const merchant = e.target.closest("[data-merchant]");
  try {
    if (action) { if (action.dataset.action === "paid" && !confirm("Pastikan dana benar-benar masuk di aplikasi merchant. Tandai invoice lunas?")) return; action.disabled = true; await api(`/api/admin/transactions/${encodeURIComponent(action.dataset.id)}/status`, { method: "PATCH", body: JSON.stringify({ status: action.dataset.action }) }); await load(); }
    if (merchant) { merchant.disabled = true; await api(`/api/admin/merchants/${encodeURIComponent(merchant.dataset.merchant)}`, { method: "PATCH", body: JSON.stringify({ active: merchant.dataset.active === "true" }) }); await load(); }
  } catch (x) { alert(x.message); await load(); }
});
document.querySelectorAll(".nav").forEach(b => b.onclick = () => {
  document.querySelectorAll(".nav").forEach(x => x.classList.remove("active")); b.classList.add("active");
  document.querySelectorAll(".page").forEach(x => x.classList.add("hide")); $(b.dataset.tab).classList.remove("hide"); $("title").textContent = b.textContent.trim();
});
