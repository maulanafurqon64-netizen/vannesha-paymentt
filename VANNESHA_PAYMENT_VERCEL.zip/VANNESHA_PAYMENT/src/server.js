require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const path = require("path");
const rateLimit = require("express-rate-limit");
const { Redis } = require("@upstash/redis");

const secret = process.env.JWT_SECRET;
const adminPassword = process.env.ADMIN_PASSWORD;
if (!secret || secret.length < 32 || secret.startsWith("GANTI_") || !adminPassword || adminPassword.startsWith("GANTI_")) {
  throw new Error("Atur JWT_SECRET (min. 32 karakter) dan ADMIN_PASSWORD yang kuat pada Environment Variables.");
}
const app = express();
const redis = process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN
  ? new Redis({ url: process.env.UPSTASH_REDIS_REST_URL, token: process.env.UPSTASH_REDIS_REST_TOKEN })
  : null;
if (!redis) {
  throw new Error("Tambahkan UPSTASH_REDIS_REST_URL dan UPSTASH_REDIS_REST_TOKEN pada Environment Variables.");
}
const DB_KEY = "vannesha-payment:database:v1";
async function save(db) { await redis.set(DB_KEY, db); }

const sha = value => crypto.createHash("sha256").update(value).digest("hex");
const money = n => Number.isSafeInteger(n) && n >= 1000 && n <= 100000000;
const appUrl = (req, id) => `${(process.env.PUBLIC_BASE_URL || `${req.protocol}://${req.get("host")}`).replace(/\/$/, "")}/pay/${id}`;
app.disable("x-powered-by");
app.set("trust proxy", process.env.TRUST_PROXY === "1" ? 1 : false);
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"],
  imgSrc: ["'self'", "data:"], objectSrc: ["'none'"], frameAncestors: ["'none'"]
}}}));
app.use(express.json({ limit: "100kb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "..", "public")));
// Each serverless request loads its own snapshot from persistent Redis storage.
app.use(async (req, res, next) => {
  try {
    const saved = await redis.get(DB_KEY);
    req.db = saved && typeof saved === "object" ? {
      merchants: Array.isArray(saved.merchants) ? saved.merchants : [],
      transactions: Array.isArray(saved.transactions) ? saved.transactions : []
    } : { merchants: [], transactions: [] };
    next();
  } catch (error) {
    console.error("Database Redis unavailable:", error.message);
    res.status(503).json({ error: "Database sementara tidak tersedia. Coba lagi nanti." });
  }
});
const loginLimit = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false });
const apiLimit = rateLimit({ windowMs: 60 * 1000, limit: 60, standardHeaders: true, legacyHeaders: false });
const publicLimit = rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });
function admin(req, res, next) {
  try {
    const token = req.cookies.vp_session;
    if (!token) throw new Error("missing");
    const payload = jwt.verify(token, secret);
    if (payload.role !== "admin") throw new Error("role");
    req.user = payload; next();
  } catch { res.status(401).json({ error: "Login admin diperlukan." }); }
}
function merchant(req, res, next) {
  const token = (req.get("authorization") || "").replace(/^Bearer\s+/i, "");
  const m = token && req.db.merchants.find(x => x.keyHash === sha(token) && x.active);
  if (!m) return res.status(401).json({ error: "API key tidak valid." });
  req.merchant = m; next();
}
function cleanText(v, max = 120) { return typeof v === "string" ? v.trim().slice(0, max) : ""; }
app.get("/api/health", (_, res) => res.json({ ok: true, mode: "manual_qris", provider: "static_qris_manual_review", automaticPayment: false }));
app.post("/api/admin/login", loginLimit, (req, res) => {
  const { username, password } = req.body || {};
  if (username !== (process.env.ADMIN_USERNAME || "admin") || password !== adminPassword)
    return res.status(401).json({ error: "Username atau password salah." });
  const token = jwt.sign({ role: "admin" }, secret, { expiresIn: "8h" });
  res.cookie("vp_session", token, { httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000, path: "/" });
  res.json({ ok: true });
});
app.post("/api/admin/logout", (_, res) => { res.clearCookie("vp_session", { path: "/" }); res.json({ ok: true }); });
app.get("/api/admin/me", admin, (_, res) => res.json({ ok: true }));
app.get("/api/admin/stats", admin, (req, res) => {
  const paid = req.db.transactions.filter(x => x.status === "paid");
  res.json({ merchants: req.db.merchants.length, total: req.db.transactions.length,
    pending: req.db.transactions.filter(x => x.status === "pending").length,
    reported: req.db.transactions.filter(x => x.status === "reported").length,
    paid: paid.length, failed: req.db.transactions.filter(x => x.status === "failed").length,
    volume: paid.reduce((sum, x) => sum + x.amount, 0) });
});
app.get("/api/admin/merchants", admin, (req, res) => res.json(req.db.merchants.map(({ id, name, active, createdAt }) => ({ id, name, active, createdAt }))));
app.post("/api/admin/merchants", admin, async (req, res) => {
  const name = cleanText(req.body?.name, 80);
  if (name.length < 2) return res.status(400).json({ error: "Nama merchant minimal 2 karakter." });
  const key = "vpay_live_" + crypto.randomBytes(32).toString("hex");
  const m = { id: crypto.randomUUID(), name, keyHash: sha(key), active: true, createdAt: new Date().toISOString() };
  req.db.merchants.push(m); await save(req.db);
  res.status(201).json({ merchant: { id: m.id, name }, apiKey: key, note: "Simpan sekarang; API key hanya ditampilkan sekali." });
});
app.patch("/api/admin/merchants/:id", admin, async (req, res) => {
  const m = req.db.merchants.find(x => x.id === req.params.id);
  if (!m) return res.status(404).json({ error: "Merchant tidak ditemukan." });
  m.active = req.body?.active === true; await save(req.db); res.json({ ok: true, active: m.active });
});
app.get("/api/admin/transactions", admin, (req, res) => res.json(req.db.transactions.slice().reverse().map(x => ({
  id: x.id, merchantId: x.merchantId, merchantName: x.merchantName, externalId: x.externalId,
  amount: x.amount, description: x.description, status: x.status, createdAt: x.createdAt,
  expiresAt: x.expiresAt, customerReportedAt: x.customerReportedAt, paidAt: x.paidAt
}))));
app.patch("/api/admin/transactions/:id/status", admin, async (req, res) => {
  const t = req.db.transactions.find(x => x.id === req.params.id);
  if (!t) return res.status(404).json({ error: "Transaksi tidak ditemukan." });
  const status = req.body?.status;
  if (!["paid", "failed", "pending"].includes(status)) return res.status(400).json({ error: "Status tidak valid." });
  if (t.status === "paid" && status !== "paid") return res.status(409).json({ error: "Transaksi yang sudah dibayar tidak dapat dibatalkan dari panel." });
  t.status = status;
  if (status === "paid") t.paidAt = new Date().toISOString();
  else delete t.paidAt;
  t.reviewedAt = new Date().toISOString(); await save(req.db); res.json({ ok: true, status: t.status });
});
app.post("/api/v1/payments", apiLimit, merchant, async (req, res) => {
  const externalId = cleanText(req.body?.external_id, 100);
  const description = cleanText(req.body?.description, 160);
  const amount = req.body?.amount;
  if (!externalId || !money(amount)) return res.status(400).json({ error: "external_id wajib diisi dan amount harus Rp1.000–Rp100.000.000." });
  if (req.db.transactions.some(x => x.merchantId === req.merchant.id && x.externalId === externalId))
    return res.status(409).json({ error: "external_id sudah digunakan oleh merchant ini." });
  const now = new Date();
  const tx = { id: crypto.randomUUID(), merchantId: req.merchant.id, merchantName: req.merchant.name,
    externalId, amount, description, status: "pending", createdAt: now.toISOString(),
    expiresAt: new Date(now.getTime() + 30 * 60 * 1000).toISOString() };
  req.db.transactions.push(tx); await save(req.db);
  res.status(201).json({ id: tx.id, external_id: externalId, amount, status: tx.status, payment_url: appUrl(req, tx.id), expires_at: tx.expiresAt,
    note: "QRIS statis: pelanggan harus memasukkan nominal tepat. Admin wajib mencocokkan pembayaran sebelum menandai lunas." });
});
app.get("/api/v1/payments/:id", apiLimit, merchant, (req, res) => {
  const t = req.db.transactions.find(x => x.id === req.params.id && x.merchantId === req.merchant.id);
  if (!t) return res.status(404).json({ error: "Transaksi tidak ditemukan." });
  res.json({ id: t.id, external_id: t.externalId, amount: t.amount, status: t.status, created_at: t.createdAt, paid_at: t.paidAt || null });
});
app.get("/api/public/payments/:id", publicLimit, (req, res) => {
  const t = req.db.transactions.find(x => x.id === req.params.id);
  if (!t) return res.status(404).json({ error: "Invoice tidak ditemukan." });
  res.json({ id: t.id, merchant: t.merchantName, external_id: t.externalId, amount: t.amount,
    description: t.description, status: t.status, created_at: t.createdAt, expires_at: t.expiresAt, reported_at: t.customerReportedAt || null });
});
app.post("/api/public/payments/:id/report", publicLimit, async (req, res) => {
  const t = req.db.transactions.find(x => x.id === req.params.id);
  if (!t) return res.status(404).json({ error: "Invoice tidak ditemukan." });
  if (t.status !== "pending") return res.status(409).json({ error: "Invoice tidak lagi menunggu pembayaran." });
  t.status = "reported"; t.customerReportedAt = new Date().toISOString(); await save(req.db);
  res.json({ ok: true, status: t.status, message: "Laporan diterima. Pembayaran tetap menunggu pemeriksaan admin." });
});
app.get("/pay/:id", (_, res) => res.sendFile(path.join(__dirname, "..", "public", "checkout.html")));
app.get("*", (_, res) => res.sendFile(path.join(__dirname, "..", "public", "index.html")));
const port = Number(process.env.PORT || 3000);
if (require.main === module) {
  app.listen(port, "0.0.0.0", () => console.log(`VANNESHA PAYMENT berjalan di http://127.0.0.1:${port}`));
}
module.exports = app;
