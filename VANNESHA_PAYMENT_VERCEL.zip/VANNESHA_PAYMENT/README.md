# VANNESHA PAYMENT — Vercel deployment build

Website Express untuk membuat invoice dan mengelola pembayaran QRIS **secara manual**. Paket ini sudah disiapkan sebagai Vercel Function dan menggunakan Upstash Redis untuk penyimpanan data persisten (bukan file lokal serverless).

> **PENTING:** Ini bukan payment service provider (PSP), bukan QRIS dinamis, dan bukan pembayaran otomatis. Pelanggan scan QRIS statis, memasukkan nominal secara manual, lalu admin wajib mencocokkan dana masuk pada aplikasi/portal merchant sebelum menandai transaksi lunas. Tombol “Saya sudah membayar” hanya membuat laporan pelanggan.

## 1. Persiapan

- Akun GitHub.
- Akun Vercel.
- Database Upstash Redis gratis untuk prototipe.
- QRIS statis milik merchant yang sah. File QRIS bawaan ada di `public/assets/gopay-qris.jpg`; ganti dengan QRIS milikmu jika memang berhak menggunakannya.

## 2. Buat database Upstash

1. Buat database Redis di https://console.upstash.com/.
2. Pilih region yang dekat dengan lokasi pengunjung bila tersedia.
3. Buka detail database, salin **UPSTASH_REDIS_REST_URL** dan **UPSTASH_REDIS_REST_TOKEN**.
4. Paket gratis Upstash memiliki batas penggunaan; pantau kuota di dashboard Upstash.

## 3. Deploy ke Vercel

1. Upload folder project ini ke repository GitHub baru. Jangan upload `.env`, token, atau password.
2. Masuk ke https://vercel.com/new lalu import repository tersebut.
3. Framework Preset: **Other**. Build Command dan Output Directory boleh dikosongkan; Vercel memakai `vercel.json`.
4. Di Project Settings → Environment Variables, tambahkan:

| Name | Value |
|---|---|
| `NODE_ENV` | `production` |
| `JWT_SECRET` | string acak minimal 32 karakter |
| `ADMIN_USERNAME` | username admin pilihanmu |
| `ADMIN_PASSWORD` | password unik yang kuat |
| `PUBLIC_BASE_URL` | `https://NAMA-PROJECT.vercel.app` |
| `UPSTASH_REDIS_REST_URL` | URL dari Upstash |
| `UPSTASH_REDIS_REST_TOKEN` | token dari Upstash |

Buat secret acak di komputer/Termux dengan:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Jangan kirim secret atau token tersebut ke siapa pun. Jangan gunakan contoh placeholder.

5. Deploy / Redeploy. Setelah berhasil, buka URL Vercel. Endpoint pemeriksaan: `/api/health`.
6. Login admin menggunakan `ADMIN_USERNAME` dan `ADMIN_PASSWORD` yang kamu masukkan sendiri.

## 4. Tes lokal

```bash
npm install
cp .env.example .env
# Edit .env dan isi semua variabel dengan kredensial sendiri
npm start
```

Buka `http://127.0.0.1:3000`.

## 5. Fitur

- Dashboard admin dan login cookie HttpOnly.
- Statistik transaksi.
- Pembuatan/nonaktifkan merchant dan API key.
- API pembuatan invoice dan cek status.
- Checkout pelanggan dan QRIS statis.
- Laporan pembayaran dari pelanggan.
- Verifikasi manual oleh admin.
- Penyimpanan data pada Upstash Redis.

## 6. Batasan penting

- **Tidak ada auto-confirm.** QRIS statis tidak mengirim notifikasi pembayaran ke aplikasi ini. Integrasi otomatis memerlukan provider/acquirer resmi, akun merchant yang disetujui, kredensial API, dan webhook resmi.
- Versi ini merupakan starter/prototipe dengan penyimpanan snapshot Redis sederhana. Jangan gunakan untuk menampung dana, transaksi bernilai besar, atau operasional keuangan produksi sebelum dilakukan audit keamanan, uji beban/konkurensi, backup, dan penguatan database.
- Vercel Hobby gratis dibatasi untuk penggunaan personal/non-komersial. Karena toko/payment gateway yang dipakai untuk memperoleh pendapatan termasuk penggunaan komersial, jangan gunakan Hobby untuk operasional bisnis nyata; cek ketentuan Vercel dan gunakan paket yang sesuai. Sumber: https://vercel.com/docs/plans/hobby dan https://vercel.com/legal/terms.
- Persyaratan umur, KYC, dan pendaftaran merchant provider pembayaran harus dipenuhi. Bila belum memenuhi syarat, minta orang tua/wali atau badan usaha yang sah menangani pendaftaran sesuai aturan provider.

## API merchant

Semua endpoint merchant menggunakan header `Authorization: Bearer API_KEY`.

`POST /api/v1/payments`

```json
{
  "external_id": "ORDER-0001",
  "amount": 25000,
  "description": "Pembelian produk"
}
```

`GET /api/v1/payments/TRANSACTION_ID` untuk cek status.
